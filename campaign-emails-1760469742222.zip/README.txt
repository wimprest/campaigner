Campaign Email Export
Generated: 2025-10-14T19:22:22.217Z
Campaign: campaign
Total Emails: 7

Folders:
- mjml/    : MJML source files (editable email templates)
- html/    : HTML preview files with conversion instructions
- metadata/: Email metadata and settings

IMPORTANT: Converting MJML to HTML

The .mjml files contain professional email templates. To use them:

Option 1 - Online Converter (Free):
1. Go to https://mjml.io/try-it-live
2. Copy content from .mjml file
3. Paste into the editor
4. Copy the generated HTML
5. Import into your email platform (SendGrid, Mailchimp, etc.)

Option 2 - MJML API (For automation):
POST your MJML to: https://api.mjml.io/v1/render
Get your API key at: https://mjml.io/api

Option 3 - Node.js/CLI:
npm install -g mjml
mjml input.mjml -o output.html

The HTML files in this ZIP show template previews and instructions.
Edit the .mjml files to customize your emails!
